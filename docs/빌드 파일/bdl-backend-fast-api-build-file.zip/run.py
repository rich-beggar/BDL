"""
FastAPI 서버 실행 스크립트
"""
import os
import uvicorn
import argparse

if __name__ == "__main__":
  # 커맨드 라인 인자 파싱
  parser = argparse.ArgumentParser(description="FastAPI 트레이딩 서버 실행")
  parser.add_argument("--host", default="127.0.0.1", help="호스트 주소")
  parser.add_argument("--port", type=int, default=8000, help="포트 번호")
  parser.add_argument("--reload", action="store_true", default=False, help="자동 리로드 비활성화")
  args = parser.parse_args()

  # 환경 변수에서 포트 설정을 가져옴 (배포 환경 대응)
  port = int(os.environ.get("PORT", args.port))

  print(f"FastAPI 서버를 시작합니다... (호스트: {args.host}, 포트: {port})")

  uvicorn.run(
      "app.main:app",
      host=args.host,
      port=port,
      reload=args.reload
  )