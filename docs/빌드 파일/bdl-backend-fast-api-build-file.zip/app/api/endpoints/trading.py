"""
트레이딩 관련 API 엔드포인트
"""
import json
from fastapi import APIRouter, HTTPException, Request, Depends
from fastapi.responses import JSONResponse
from app.models.schemas import TradingStartRequest, TradingStopRequest
from app.services.trading_service import (
    start_algorithm_trading,
    stop_algorithm_trading
)
import logging

logger = logging.getLogger("app.api.trading")

router = APIRouter(tags=["trading"])

@router.post("/auto-trading/start")
async def start_trading(request: Request):
    """
    트레이딩 알고리즘 시작 엔드포인트
    """
    try:
        # 요청 본문을 직접 읽기
        body = await request.body()
        logger.info(f"Received raw request body: {body}")

        # JSON으로 파싱
        try:
            request_data = json.loads(body)
        except json.JSONDecodeError:
            logger.error(f"JSON 파싱 실패, 원본 데이터: {body}")
            raise HTTPException(status_code=400, detail="유효하지 않은 JSON 형식입니다.")

        # 데이터 검증을 위한 Pydantic 모델로 변환
        trading_request = TradingStartRequest(
            algorithmId=request_data.get("algorithmId"),
            companyId=request_data.get("companyId")
        )

        # 서비스 계층 호출
        result = await start_algorithm_trading(trading_request.algorithmId, trading_request.companyId)
        logger.info(f"Returning result: {result}, type: {type(result)}")
        return JSONResponse(
            content=result,
            media_type="application/json"
        )

    except HTTPException as he:
        raise he
    except Exception as e:
        logger.exception(f"요청 처리 중 오류 발생: {str(e)}")
        raise HTTPException(status_code=500, detail=f"내부 서버 오류: {str(e)}")


@router.post("/auto-trading/stop")
async def stop_trading(request: Request):
    """
    실행 중인 알고리즘 중지 엔드포인트
    """
    try:
        body = await request.body()
        request_data = json.loads(body)

        # 데이터 검증을 위한 Pydantic 모델로 변환
        stop_request = TradingStopRequest(
            algorithmId=request_data.get("algorithmId"),
            companyId=request_data.get("companyId")
        )

        # 서비스 계층 호출
        result = await stop_algorithm_trading(stop_request.algorithmId, stop_request.companyId)
        return result

    except HTTPException as he:
        raise he
    except Exception as e:
        logger.exception(f"알고리즘 중지 중 오류 발생: {str(e)}")
        raise HTTPException(status_code=500, detail=f"내부 서버 오류: {str(e)}")