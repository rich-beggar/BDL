#/app/model/model.py
from pydantic import BaseModel
from typing import Optional

# 알고리즘 모델 정의
class Algorithm(BaseModel):
    algorithmId: int
    algorithmName: str
    profitPercentToSell: Optional[float] = None
    lossPercentToSell: Optional[float] = None
    oneMinuteIncreasePercent: Optional[float] = None
    oneMinuteIncreaseAction: Optional[str] = None
    oneMinuteDecreasePercent: Optional[float] = None
    oneMinuteDecreaseAction: Optional[str] = None
    dailyIncreasePercent: Optional[float] = None
    dailyIncreaseAction: Optional[str] = None
    dailyDecreasePercent: Optional[float] = None
    dailyDecreaseAction: Optional[str] = None
    shortTermMaPeriod: Optional[int] = None
    longTermMaPeriod: Optional[int] = None
    entryMethod: Optional[str] = None
    entryInvestmentMethod: Optional[str] = None
    entryFixedAmount: Optional[int] = None
    entryFixedPercentage: Optional[int] = None
    exitMethod: Optional[str] = None
    exitInvestmentMethod: Optional[str] = None
    exitFixedAmount: Optional[int] = None
    exitFixedPercentage: Optional[int] = None

# 회사 데이터 모델 (필요시 확장)
class Company(BaseModel):
    companyId: int
    companyName: str = "Unknown"

# 트레이딩 요청 모델
class TradingRequest(BaseModel):
    algorithmId: int
    companyId: int