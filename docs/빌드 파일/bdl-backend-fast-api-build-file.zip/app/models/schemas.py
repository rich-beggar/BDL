"""
API 요청 및 응답을 위한 Pydantic 모델
"""
from pydantic import BaseModel, Field
from typing import Dict, Any, Optional, List


class TradingStartRequest(BaseModel):
    """트레이딩 시작 요청 스키마"""
    algorithmId: int = Field(..., description="알고리즘 ID")
    companyId: int = Field(..., description="회사 ID")


class TradingStopRequest(BaseModel):
    """트레이딩 중지 요청 스키마"""
    algorithmId: int = Field(..., description="알고리즘 ID")
    companyId: int = Field(..., description="회사 ID")


class TradingStartResponse(BaseModel):
    """트레이딩 시작 응답 스키마"""
    status: str
    message: str
    taskId: str
    celeryTaskId: str
    algorithmDetails: Dict[str, Any]


class TradingStopResponse(BaseModel):
    """트레이딩 중지 응답 스키마"""
    status: str
    message: str


class AlgorithmStatus(BaseModel):
    """알고리즘 상태 스키마"""
    status: str
    celery_state: Optional[str] = None
    celery_info: Optional[Dict[str, Any]] = None
    info: Optional[Dict[str, Any]] = None


class AllAlgorithmStatusesResponse(BaseModel):
    """모든 알고리즘 상태 응답 스키마"""
    runningAlgorithms: int
    algorithms: Dict[str, Any]