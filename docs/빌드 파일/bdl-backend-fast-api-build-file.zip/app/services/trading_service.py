"""
트레이딩 관련 비즈니스 로직을 처리하는 서비스 계층
"""
from fastapi import HTTPException

from app.core.tasks import get_celery_app
from app.db.database import get_algorithm_by_id, get_company_by_id
from app.core.tasks import get_celery_app
from app.core.tasks import run_trading_algorithm
import logging
import json
logger = logging.getLogger("app.services.trading")
# Celery 앱 인스턴스 가져오기
celery_app = get_celery_app()

async def start_algorithm_trading(algorithm_id: int, company_id: int):
    """
    트레이딩 알고리즘 시작
    """
    logger.info(f"Trading request received - algorithmId: {algorithm_id}, companyId: {company_id}")

    # DB에서 알고리즘 정보 조회
    algorithm_data = get_algorithm_by_id(algorithm_id)
    if not algorithm_data:
        raise HTTPException(status_code=404, detail=f"알고리즘 ID {algorithm_id}를 찾을 수 없습니다.")
    # 1분봉 & 일봉 관련 값 확인
    has_minute_data = any([
        algorithm_data.get("oneMinuteIncreasePercent"),
        algorithm_data.get("oneMinuteIncreaseAction"),
        algorithm_data.get("oneMinuteDecreasePercent"),
        algorithm_data.get("oneMinuteDecreaseAction"),
    ])

    has_daily_data = any([
        algorithm_data.get("dailyIncreasePercent"),
        algorithm_data.get("dailyIncreaseAction"),
        algorithm_data.get("dailyDecreasePercent"),
        algorithm_data.get("dailyDecreaseAction"),
    ])

    # check_type 자동 결정
    if has_minute_data and not has_daily_data:
        check_type = "minute"
    elif has_daily_data and not has_minute_data:
        check_type = "daily"
    else:
        raise HTTPException(status_code=400,
                            detail="1분봉 또는 일봉 중 하나 이상의 설정이 필요합니다.")

    logger.info(f"Determined check_type: {check_type}")

    # 작업 ID 생성
    import time

    task_id = f"{algorithm_id}_{company_id}_{int(time.time())}"
    logger.info(f"Generated task_id: {task_id}")

    task_meta_pattern = f"celery-task-meta-{algorithm_id}_{company_id}_*"
    matching_keys = celery_app.backend.client.keys(task_meta_pattern)
    logger.info(f"Matching keys1: {matching_keys}")

    # 실행 중인 작업이 있는지 확인하는 플래그
    has_running_task = False
    running_task_id = None

    # 각 키 확인 및 처리
    for key in matching_keys:
        #알고리즘이 이미 실행 중인지 확인
        key_str = key.decode('utf-8') if isinstance(key, bytes) else key
        logger.info(f" key: {key}")
        task_meta = celery_app.backend.client.get(key_str)
        if task_meta:
            task_data = json.loads(task_meta)
            # 상태 확인
            status = task_data.get("status")
            logger.info(f"Found task {key} with status: {status}")
            # REVOKED 상태인 경우 메타데이터 삭제
            if task_data.get("status") == "REVOKED":
                # 작업 메타데이터 삭제
                celery_app.backend.delete(key)
            elif status in ["SUCCESS","PENDING", "STARTED", "RETRY"]:
                # 실행 중인 작업이 있는 경우
                has_running_task = True
                running_task_id = key_str.replace('celery-task-meta-', '')
                logger.info(
                    f"Task {running_task_id} is still running with status: {status}")
        if has_running_task:
            logger.info(f"Task {key} is still running with status: {status}")
            return {
                "status": "already_running",
                "message": f"알고리즘 {algorithm_id}는 이미 회사 {company_id}에 대해 실행 중입니다.",
                "celeryTaskId": running_task_id,
                "algorithmDetails": algorithm_data
            }

    #Celery 작업 시작
    celery_task = run_trading_algorithm.apply_async(
        args=[algorithm_id, company_id, algorithm_data, check_type],
        kwargs={"init": True},
        task_id=task_id
    )
    logger.info(f"celery_task: {celery_task}")
    # 응답 반환
    return {
        "status": "success",
        "message": f"알고리즘 {algorithm_id}와 회사 {company_id}에 대한 트레이딩이 시작되었습니다.",
        "taskId": task_id,
        "celeryTaskId": celery_task.id,
        "algorithmDetails": algorithm_data
    }


async def stop_algorithm_trading(algorithm_id: int, company_id: int):
    """
    실행 중인 알고리즘 중지
    """
    # 패턴 매칭 사용 (시간 정보 포함된 ID 대응)
    base_task_id = f"{algorithm_id}_{company_id}"
    logger.info(
        f"중지 요청 받음: algorithm_id={algorithm_id}, company_id={company_id}")

    # 스케줄러에서 확인
    i = celery_app.control.inspect()
    scheduled = i.scheduled() or {}
    reserved = i.reserved() or {}
    active = i.active() or {}

    task_found = False
    tasks_stopped = 0

    # 모든 작업자의 scheduled, reserved, active 작업 검색
    # 디버깅을 위한 로깅 추가
    logger.info(f"찾을 기본 작업 ID 패턴: {base_task_id}")
    for category_name, worker_tasks in [("scheduled", scheduled),
                                        ("reserved", reserved),
                                        ("active", active)]:
        if worker_tasks:
            for worker, tasks in worker_tasks.items():
                logger.info(f"{category_name} 작업: {worker} - {len(tasks)}개")
                for task in tasks:
                    task_id = task['request'].get('id', '')

                    if task_id:
                        logger.info(
                            f"  - 작업 ID: {task_id}, startswith 결과: {task_id.startswith(base_task_id)}")
                        if task_id.startswith(base_task_id):
                            logger.info(f"{category_name} 작업 중지: {task_id}")
                            celery_app.control.revoke(task_id, terminate=True)
                            task_found = True
                            tasks_stopped += 1

    # Redis에서 패턴 매칭으로 메타데이터 찾기
    meta_pattern = f"celery-task-meta-{base_task_id}*"
    matching_keys = celery_app.backend.client.keys(meta_pattern)

    for key in matching_keys:
        key_str = key.decode('utf-8') if isinstance(key, bytes) else key
        task_id = key_str.replace('celery-task-meta-', '')

        # 이미 revoke 되지 않은 작업만 처리
        task_meta = celery_app.backend.client.get(key)
        if task_meta:
            task_meta_str = task_meta.decode('utf-8') if isinstance(task_meta,
                                                                    bytes) else task_meta
            task_data = json.loads(task_meta_str)
            status = task_data.get("status")

            if status not in ["REVOKED"]:
                logger.info(f"메타데이터에서 찾은 작업 중지: {task_id}, 상태: {status}")
                celery_app.control.revoke(task_id, terminate=True)
                task_found = True
                tasks_stopped += 1

        # 선택적으로 메타데이터 삭제
        try:
            delete_result = celery_app.backend.client.delete(key)
            delete_result2 = celery_app.backend.client.delete(key_str)
            logger.info(f"메타데이터 삭제: {key_str}, 결과1 { delete_result }, 결과2 : {delete_result2}")
        except Exception as e:
            logger.warning(f"메타데이터 삭제 실패: {str(e)}")

    if task_found:
        return {
            "status": "success",
            "message": f"알고리즘 {algorithm_id}의 회사 {company_id}에 대한 트레이딩이 중지되었습니다. (중지된 작업 수: {tasks_stopped})"
        }
    else:
        return {
            "status": "failed",
            "message": f"알고리즘 {algorithm_id}의 회사 {company_id}에 대한 트레이딩을 찾을 수 없습니다.)"
        }