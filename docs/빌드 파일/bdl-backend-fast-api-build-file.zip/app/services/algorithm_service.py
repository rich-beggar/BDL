
# app/services/algorithm_service.py
"""
알고리즘 기술적 분석 및 트레이딩 신호 생성을 위한 서비스
"""
from typing import Dict, List, Optional, Tuple
import pandas as pd
import time
import numpy as np
import pytz
from datetime import datetime, timedelta
import logging
from app.db.database import (
  get_stock_minute_data,
  get_stock_daily_data
)

KST = pytz.timezone('Asia/Seoul')
logger = logging.getLogger("app.services.algorithm")


def is_market_open() -> bool:
  """
  TODO: 공휴일 체크

    현재 주식 시장이 열려있는지 확인 (KST 기준)
    한국 시장 시간: 9:00-15:00 KST (UTC+9)
    UTC 기준으로는: 00:00-06:30 UTC

    Returns:
        bool: 시장 개장 여부
    """
  now = datetime.now(KST)  # KST 사용

  # 주말 체크
  if now.weekday() >= 5:  # 5=토요일, 6=일요일
    return False

  # 시간 체크 (9:00 - 15:30)
  market_open = now.replace(hour=9, minute=0, second=0, microsecond=0)
  market_close = now.replace(hour=15, minute=0, second=0, microsecond=0)

  return market_open <= now <= market_close


def check_ma_crossover(data):
  """
  DB에서 제공하는 이동평균선 데이터(fiveAverage, twentyAverage)를 활용하여
  골든 크로스/데드 크로스 여부 확인

  Args:
      data: 일봉 데이터 DataFrame (fiveAverage, twentyAverage 컬럼 포함)

  Returns:
      signal: 매매 신호 (BUY/SELL/HOLD)
      reason: 신호 발생 이유
  """
  if data is None or len(data) < 2:
    return "HOLD", "이동평균선 분석을 위한 충분한 데이터 없음"

  # 최신 두 개의 데이터 포인트 가져오기
  current_short_ma = data['fiveAverage'].iloc[-1]
  current_long_ma = data['twentyAverage'].iloc[-1]
  previous_short_ma = data['fiveAverage'].iloc[-2]
  previous_long_ma = data['twentyAverage'].iloc[-2]

  # 골든 크로스 확인 (5일선이 20일선을 아래서 위로 돌파)
  if previous_short_ma <= previous_long_ma and current_short_ma > current_long_ma:
    return "BUY", "골든 크로스 발생 (5일 이동평균선이 20일 이동평균선을 상향 돌파)"

  # 데드 크로스 확인 (5일선이 20일선을 위에서 아래로 돌파)
  elif previous_short_ma >= previous_long_ma and current_short_ma < current_long_ma:
    return "SELL", "데드 크로스 발생 (5일 이동평균선이 20일 이동평균선을 하향 돌파)"

  return "HOLD", "이동평균선 교차 없음"

def calculate_price_change_percent(df: pd.DataFrame) -> float:
  """
  분봉 데이터의 가격 변동률(%) 계산

  Returns:
      float: 가격 변동률(%)
  """

  # 첫 봉의 시가와 마지막 봉의 종가 비교
  first_open = df.iloc[0]['openPrice']
  last_close = df.iloc[-1]['closePrice']

  percent_change = ((last_close - first_open) / first_open) * 100

  return percent_change


def is_price_increased(df: pd.DataFrame, threshold_percent: int) -> bool:
  """
  분봉 기준 가격이 threshold_percent 이상 상승했는지 확인
  """
  percent_change = calculate_price_change_percent(df)
  return percent_change >= threshold_percent


def is_price_decreased(df: pd.DataFrame, threshold_percent: int) -> bool:
  """
  분봉 기준 가격이 threshold_percent 이상 하락했는지 확인
  """
  percent_change = calculate_price_change_percent(df)
  return percent_change <= -threshold_percent  # 마이너스 부호 주의

#아침 9시마다 시작될 함수
#전일와 전전일를 비교
#전일 대비 변동률
def calculate_daily_price_change_percent(df: pd.DataFrame) -> float:
    """
    일봉 데이터의 가격 변동률(%) 계산

    Returns:
        float: 가격 변동률(%)
    """
    if len(df) < 2:
      return 0.0

    # 전일 종가와 전전일 종가 비교
    previous_close = df.iloc[-2]['closePrice'] # 전전일
    latest_close = df.iloc[-1]['closePrice'] # 전일

    percent_change = ((latest_close - previous_close) / previous_close) * 100

    return percent_change


def is_daily_price_increased(df: pd.DataFrame, threshold_percent: int) -> bool:
  """
  일봉 기준 가격이 threshold_percent 이상 상승했는지 확인
  전일 종가가 전전일 종가 대비 상승률 확인
  """
  percent_change = calculate_daily_price_change_percent(df)
  return percent_change >= threshold_percent


def is_daily_price_decreased(df: pd.DataFrame, threshold_percent: int) -> bool:
  """
  일봉 기준 가격이 threshold_percent 이상 하락했는지 확인
  전일 종가가 전전일 종가 대비 하락률 확인
  """
  percent_change = calculate_daily_price_change_percent(df)
  return percent_change <= -threshold_percent

def check_minute_data(algorithm_data, company_id):
    """1분봉 데이터 분석 및 매매 신호 생성"""
    try:
        now = datetime.now()
        # 현재 시간 기준 이전 30분 데이터 가져오기
        logger.info(f"분봉 데이터 끌어오는 시간 {now} ~ {now - timedelta(minutes=2)}")
        minute_end = now.replace(second=0, microsecond=0)
        minute_start = minute_end - timedelta(minutes=2)

        # 실제 분봉 데이터 조회 (DB에서)
        minute_data = get_stock_minute_data(company_id, minute_start, minute_end)

        # 데이터가 없으면 최대 3번까지 재시도
        retry_count = 0
        while (
            minute_data is None or len(minute_data) == 0) and retry_count < 3:
          logger.info(f"분봉 데이터가 없습니다. {retry_count + 1}번째 재시도...")
          time.sleep(3)  # 3초 대기
          minute_data = get_stock_minute_data(company_id, minute_start,
                                              minute_end)
          retry_count += 1

        if minute_data is None or len(minute_data) == 0:
            logger.warning(f"분봉 데이터를 찾을 수 없습니다. 회사 ID: {company_id}")
            return {"signal": "HOLD", "reasons": ["분봉 데이터 없음"]}

        # 마지막 가격 및 가격 변화율 계산
        price_change_percent = calculate_price_change_percent(minute_data)
        # 마지막 가격 가져오기
        last_price = minute_data['closePrice'].iloc[-1] if len(
            minute_data) > 0 else None

        # 알고리즘 조건에 따른 매매 신호 생성
        signal = "HOLD"
        reasons = []

        logger.info(f"1분봉 변화율{price_change_percent} 내 임계값")

        # 상승 조건 확인
        increase_threshold = algorithm_data.get('oneMinuteIncreasePercent')
        increase_action = algorithm_data.get('oneMinuteIncreaseAction')
        if is_price_increased(minute_data, increase_threshold):
            signal = increase_action
            reasons.append(
                f"1분봉 {price_change_percent:.2f}% 상승 (임계값: {increase_threshold}%)")

        # 하락 조건 확인
        decrease_threshold = algorithm_data.get('oneMinuteDecreasePercent')
        decrease_action = algorithm_data.get('oneMinuteDecreaseAction')

        if decrease_threshold is not None and decrease_action is not None:
            if is_price_decreased(minute_data, decrease_threshold):
                signal = decrease_action
                reasons.append(
                    f"1분봉 {abs(price_change_percent):.2f}% 하락 (임계값: {decrease_threshold}%)")
        return {
            "signal": signal,
            "reasons": reasons,
            "lastPrice": last_price,
            "priceChangePercent": price_change_percent
        }
    except Exception as e:
        logger.exception(f"분봉 데이터 분석 중 오류 발생: {str(e)}")
        return {"signal": "HOLD", "reasons": [f"분석 오류: {str(e)}"]}

def check_daily_data(algorithm_data, company_id):
    """일봉 데이터 분석 및 매매 신호 생성"""
    try:
        # 현재 날짜 기준 어제랑 그저께 데이터 가져오기
        now = datetime.now()
        end_date = now.replace(hour=0, minute=0, second=0,
                               microsecond=0)  # 오늘 0시)
        start_date = end_date - timedelta(days=2)

        # 실제 일봉 데이터 조회 (DB에서)
        daily_data = get_stock_daily_data(company_id, start_date, end_date)

        if daily_data is None or len(daily_data) < 2:  # 최소 2일 데이터 필요
            logger.warning(f"충분한 일봉 데이터를 찾을 수 없습니다. 회사 ID: {company_id}")
            return {"signal": "HOLD", "reasons": ["충분한 일봉 데이터 없음 (최소 2일 필요)"]}

        # 마지막 가격 및 가격 변화율 계산
        last_price = daily_data['closePrice'].iloc[-1]
        price_change_percent = calculate_daily_price_change_percent(daily_data)

        # 알고리즘 조건에 따른 매매 신호 생성
        signal = "HOLD"
        reasons = []

        # 상승 조건 확인
        increase_threshold = algorithm_data.get('dailyIncreasePercent')
        increase_action = algorithm_data.get('dailyIncreaseAction')

        if increase_threshold is not None and increase_action is not None:
            if is_daily_price_increased(daily_data, increase_threshold):
                signal = increase_action
                reasons.append(
                    f"일봉 {price_change_percent:.2f}% 상승 (임계값: {increase_threshold}%)")

        # 하락 조건 확인
        decrease_threshold = algorithm_data.get('dailyDecreasePercent')
        decrease_action = algorithm_data.get('dailyDecreaseAction')

        if decrease_threshold is not None and decrease_action is not None:
            if is_daily_price_decreased(daily_data, decrease_threshold):
                signal = decrease_action
                reasons.append(
                    f"일봉 {abs(price_change_percent):.2f}% 하락 (임계값: {decrease_threshold}%)")

        # 2. 이동평균선 교차(골든 크로스/데드 크로스) 확인
        if 'fiveAverage' in daily_data.columns and 'twentyAverage' in daily_data.columns:
          ma_signal, ma_reason = check_ma_crossover(daily_data)
          if ma_signal != "HOLD":
            signal = ma_signal
            reasons.append(ma_reason)

        return {
            "signal": signal,
            "reasons": reasons,
            "lastPrice": last_price,
            "priceChangePercent": price_change_percent
        }
    except Exception as e:
        logger.exception(f"일봉 데이터 분석 중 오류 발생: {str(e)}")
        return {"signal": "HOLD", "reasons": [f"분석 오류: {str(e)}"]}



def check_profit_loss_thresholds(entry_price: float, current_price: float,
    profit_percent: int, loss_percent: int) -> Tuple[bool, bool]:
  """
  이익/손실 임계값 확인

  Returns:
      Tuple[bool, bool]: (profit_threshold_reached, loss_threshold_reached)
  """
  percent_change = ((current_price - entry_price) / entry_price) * 100

  profit_threshold_reached = percent_change >= profit_percent
  loss_threshold_reached = percent_change <= -loss_percent

  return profit_threshold_reached, loss_threshold_reached


def get_trading_data(company_id: int, lookback_days_minute: int = 1,
    lookback_days_daily: int = 30) -> Tuple[
  Optional[pd.DataFrame], Optional[pd.DataFrame]]:
  """
  트레이딩에 필요한 분봉, 일봉 데이터 가져오기
  """
  now = datetime.now()

  # 데이터 조회 기간 설정
  minute_start = now - timedelta(days=lookback_days_minute)
  daily_start = now - timedelta(days=lookback_days_daily)

  # 분봉 데이터 조회
  minute_df = get_stock_minute_data(company_id, minute_start, now)

  # 일봉 데이터 조회
  daily_df = get_stock_daily_data(company_id, daily_start, now, period_type=1)

  return minute_df, daily_df



# # 추가적인 기술적 분석 함수들 (필요시 구현)
# def calculate_rsi(df: pd.DataFrame, period: int = 14) -> pd.Series:
#   """
#   상대강도지수(RSI) 계산
#   """
#   delta = df['closePrice'].diff()
#   gain = delta.where(delta > 0, 0).rolling(window=period).mean()
#   loss = -delta.where(delta < 0, 0).rolling(window=period).mean()
#
#   rs = gain / loss
#   rsi = 100 - (100 / (1 + rs))
#
#   return rsi
#
#
# def calculate_bollinger_bands(df: pd.DataFrame, period: int = 20,
#     num_std: float = 2.0) -> Tuple[pd.Series, pd.Series, pd.Series]:
#   """
#   볼린저 밴드 계산
#
#   Returns:
#       Tuple[pd.Series, pd.Series, pd.Series]: (upper_band, middle_band, lower_band)
#   """
#   middle_band = df['closePrice'].rolling(window=period).mean()
#   std = df['closePrice'].rolling(window=period).std()
#
#   upper_band = middle_band + (std * num_std)
#   lower_band = middle_band - (std * num_std)
#
#   return upper_band, middle_band, lower_band
#
#
# def calculate_macd(df: pd.DataFrame, fast_period: int = 12,
#     slow_period: int = 26, signal_period: int = 9) -> Tuple[
#   pd.Series, pd.Series, pd.Series]:
#   """
#   MACD(Moving Average Convergence Divergence) 계산
#
#   Returns:
#       Tuple[pd.Series, pd.Series, pd.Series]: (macd_line, signal_line, histogram)
#   """
#   exp1 = df['closePrice'].ewm(span=fast_period, adjust=False).mean()
#   exp2 = df['closePrice'].ewm(span=slow_period, adjust=False).mean()
#
#   macd_line = exp1 - exp2
#   signal_line = macd_line.ewm(span=signal_period, adjust=False).mean()
#   histogram = macd_line - signal_line
#
#   return macd_line, signal_line, histogram