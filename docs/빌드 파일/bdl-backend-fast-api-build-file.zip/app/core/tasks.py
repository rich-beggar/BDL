#app/core/tasks.py
"""
Celery 태스크 관리 및 관련 함수 정의
"""
from typing import Dict, Any
from app.celery_worker import run_trading_algorithm
import logging

# Celery 앱 인스턴스 공유를 위한 글로벌 변수
_celery_app = None

# 실행 중인 알고리즘 작업 추적을 위한 딕셔너리
running_tasks = {}

logger = logging.getLogger("app.core.tasks")


def get_celery_app():
    """
    Celery 앱 인스턴스 가져오기 (싱글톤 패턴)
    """
    global _celery_app
    if _celery_app is None:
        # Celery 모듈에서 앱 가져오기
        from app.celery_worker import celery_app as app
        _celery_app = app
    return _celery_app
