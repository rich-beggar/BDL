"""
애플리케이션 생명주기 이벤트 처리
"""
from fastapi import FastAPI
from contextlib import asynccontextmanager
from app.core.tasks import get_celery_app
import logging

from datetime import datetime, timedelta

# 데이터베이스 및 분석 관련 모듈
import pandas as pd  # DataFrame 처리를 위해 필요
from app.db.database import get_db_connection  # DB 연결 함수 (기존 코드에서 사용)
from app.db.database import (  # 주식 데이터 조회 함수들
    get_stock_minute_data,
    get_stock_daily_data
)


logger = logging.getLogger("app.core.events")
celery_app = get_celery_app()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    애플리케이션 시작 및 종료 시 이벤트 처리
    """

    logger.info("애플리케이션 시작: 분봉 데이터 확인 중...")

    try:
        # 예시로 특정 회사 ID 사용 (실제 환경에 맞게 조정 필요)
        test_company_id = 1  # 예시 회사 ID

        # 현재 시간 기준 1분 전 데이터 확인
        now = datetime.now()
        minute_end = now.replace(second=0, microsecond=0)
        minute_start = minute_end - timedelta(minutes=1)

        # 분봉 데이터 조회
        minute_data = get_stock_minute_data(test_company_id, minute_start,
                                            minute_end)

        if minute_data is None or len(minute_data) == 0:
            logger.warning(f"테스트: 분봉 데이터를 찾을 수 없습니다. 회사 ID: {test_company_id}")
        else:
            # 데이터 확인
            logger.info(f"테스트: 분봉 데이터 조회 성공. 데이터 수: {len(minute_data)}")

            # 시가, 종가 데이터 로그로 출력
            if len(minute_data) > 0:
                logger.info(
                    f"테스트: 첫 데이터 시가: {minute_data['openPrice'].iloc[0]}, 종가: {minute_data['closePrice'].iloc[0]}")
                logger.info(
                    f"테스트: 마지막 데이터 시가: {minute_data['openPrice'].iloc[-1]}, 종가: {minute_data['closePrice'].iloc[-1]}")

                # 이동평균선 데이터도 있는지 확인
                if 'fiveAverage' in minute_data.columns and 'twentyAverage' in minute_data.columns:
                    logger.info(
                        f"테스트: 이동평균선 데이터 있음 - 5일선: {minute_data['fiveAverage'].iloc[-1]}, 20일선: {minute_data['twentyAverage'].iloc[-1]}")
                else:
                    logger.warning("테스트: 이동평균선 데이터가 없습니다.")

            # DataFrame 컬럼 확인
            logger.info(f"테스트: 분봉 데이터 컬럼: {list(minute_data.columns)}")

            # 날짜 범위 확인
            first_time = minute_data.index[0] if len(minute_data) > 0 else None
            last_time = minute_data.index[-1] if len(minute_data) > 0 else None
            logger.info(f"테스트: 분봉 데이터 기간: {first_time} ~ {last_time}")

    except Exception as e:
        logger.exception(f"테스트: 분봉 데이터 확인 중 오류 발생: {str(e)}")

    # 일봉 데이터도 함께 확인
    try:
        # 현재 날짜 기준 이전 데이터 확인
        end_date = datetime.now()
        start_date = end_date - timedelta(days=1)

        # 일봉 데이터 조회
        daily_data = get_stock_daily_data(test_company_id, start_date, end_date)

        if daily_data is None or len(daily_data) == 0:
            logger.warning(f"테스트: 일봉 데이터를 찾을 수 없습니다. 회사 ID: {test_company_id}")
        else:
            # 데이터 확인
            logger.info(f"테스트: 일봉 데이터 조회 성공. 데이터 수: {len(daily_data)}")

            # 시가, 종가 데이터 로그로 출력
            if len(daily_data) > 0:
                logger.info(
                    f"테스트: 첫 일봉 데이터 시가: {daily_data['openPrice'].iloc[0]}, 종가: {daily_data['closePrice'].iloc[0]}")
                logger.info(
                    f"테스트: 마지막 일봉 데이터 시가: {daily_data['openPrice'].iloc[-1]}, 종가: {daily_data['closePrice'].iloc[-1]}")

            # DataFrame 컬럼 확인
            logger.info(f"테스트: 일봉 데이터 컬럼: {list(daily_data.columns)}")

    except Exception as e:
        logger.exception(f"테스트: 일봉 데이터 확인 중 오류 발생: {str(e)}")

    logger.info("데이터 확인 완료")

    try:
        logger.info("애플리케이션 시작: Redis에서 작업 상태 로드 중...")

        # "celery-task-meta-*" 형식의 모든 키를 가져옴
        task_result_keys = celery_app.backend.client.keys("celery-task-meta-*")
        running_task_ids_count = len(task_result_keys)  # 실행 중인 작업 수

        logger.info(f"Redis에서 {running_task_ids_count}개의 실행 중인 작업을 로드했습니다.")

    except Exception as e:
        logger.error(f"Redis에서 작업 상태 로드 중 오류 발생: {str(e)}", exc_info=True)

    yield  # 여기서 애플리케이션이 실행됨

    # 종료 시 정리 작업 (필요한 경우)
    logger.info("애플리케이션 종료: 정리 작업 수행")