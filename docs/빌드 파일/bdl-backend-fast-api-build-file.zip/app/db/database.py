#/app/database.py
# 알고리즘 데이터 조회 함수
from typing import Optional, Dict
from datetime import datetime, timedelta
import pandas as pd
from app.core.db_config import get_db_connection

def get_algorithm_by_id(algorithm_id: int) -> Optional[Dict]:
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            # 알고리즘 테이블 구조에 맞게 조회 쿼리 수정
            sql = """
            SELECT 
                algorithm_id as algorithmId,
                algorithm_name as algorithmName,
                profit_percent_to_sell as profitPercentToSell,
                loss_percent_to_sell as lossPercentToSell,
                one_minute_increase_percent as oneMinuteIncreasePercent,
                one_minute_increase_action as oneMinuteIncreaseAction,
                one_minute_decrease_percent as oneMinuteDecreasePercent,
                one_minute_decrease_action as oneMinuteDecreaseAction,
                daily_increase_percent as dailyIncreasePercent,
                daily_increase_action as dailyIncreaseAction,
                daily_decrease_percent as dailyDecreasePercent,
                daily_decrease_action as dailyDecreaseAction,
                short_term_ma_period as shortTermMaPeriod,
                long_term_ma_period as longTermMaPeriod,
                entry_method as entryMethod,
                entry_investment_method as entryInvestmentMethod,
                entry_fixed_amount as entryFixedAmount,
                entry_fixed_percentage as entryFixedPercentage,
                exit_method as exitMethod,
                exit_investment_method as exitInvestmentMethod,
                exit_fixed_amount as exitFixedAmount,
                exit_fixed_percentage as exitFixedPercentage
            FROM algorithm
            WHERE algorithm_id = %s
            """
            cursor.execute(sql, (algorithm_id,))
            result = cursor.fetchone()

            if result:
                # NULL 값을 None으로 변환
                for key, value in result.items():
                    if value == 'NULL':
                        result[key] = None

                return result
            return None
    except Exception as e:
        print(f"DB 연결 오류: {str(e)}")
        return None
    finally:
        if connection:
            connection.close()


def get_stock_minute_data(company_id: int, start_time: datetime, end_time: datetime) -> Optional[pd.DataFrame]:
    """
    특정 회사의 특정 시간대 분봉 데이터 조회
    """
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            sql = """
            SELECT 
                stock_candle_minute_id,
                open_price as openPrice,
                high_price as highPrice,
                low_price as lowPrice,
                close_price as closePrice,
                previous_day_versus as previousDayVersus,
                previous_day_versus_sign as previousDayVersusSign,
                contracting_volume as contractingVolume,
                accumulated_trade_amount as accumulatedTradeAmount,
                trading_time as tradingTime,
                five_average as fiveAverage,
                twenty_average as twentyAverage
            FROM stock_minute
            WHERE company_id = %s
              AND trading_time BETWEEN %s AND %s
            ORDER BY trading_time ASC
            """
            # 1번째 행이 가장 이른 시간
            cursor.execute(sql, (company_id,  start_time, end_time))
            results = cursor.fetchall()

            if not results:
                print(
                    f"분봉 데이터가 없습니다. 회사 ID: {company_id}, 시간: {start_time, end_time}")
                return None

            # DataFrame으로 변환
            df = pd.DataFrame(results)

            # 시간을 인덱스로 설정
            df['tradingTime'] = pd.to_datetime(df['tradingTime'])
            df = df.set_index('tradingTime')

            return df
    except Exception as e:
        print(f"분봉 데이터 조회 중 오류 발생: {str(e)}")
        return None
    finally:
        if connection:
            connection.close()


def get_stock_daily_data(company_id: int, start_date: datetime,
    end_date: datetime, period_type: int = 1) -> Optional[pd.DataFrame]:
    """
    특정 회사의 일봉 데이터를 시작 날짜부터 종료 날짜까지 조회
    period_type: 1 = 일봉, 2 = 주봉, 3 = 월봉 등
    """
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            sql = """
            SELECT 
                stock_candle_id,
                open_price as openPrice,
                high_price as highPrice,
                low_price as lowPrice,
                close_price as closePrice,
                previous_day_versus as previousDayVersus,
                previous_day_versus_sign as previousDayVersusSign,
                accumulated_volume as accumulatedVolume,
                accumulated_trade_amount as accumulatedTradeAmount,
                trading_date as tradingDate,
                five_average as fiveAverage,
                twenty_average as twentyAverage
            FROM stock_daily
            WHERE company_id = %s
              AND trading_date BETWEEN %s AND %s
              AND period_type = %s
            ORDER BY trading_date ASC
            """
            cursor.execute(sql, (company_id, start_date, end_date, period_type))
            results = cursor.fetchall()

            if not results:
                print(
                    f"일봉 데이터가 없습니다. 회사 ID: {company_id}, 기간: {start_date} ~ {end_date}")
                return None

            # DataFrame으로 변환
            df = pd.DataFrame(results)

            # 날짜를 인덱스로 설정
            df['tradingDate'] = pd.to_datetime(df['tradingDate'])
            df = df.set_index('tradingDate')

            return df
    except Exception as e:
        print(f"일봉 데이터 조회 중 오류 발생: {str(e)}")
        return None
    finally:
        if connection:
            connection.close()

# 회사 정보 조회 함수 (필요시 구현)
def get_company_by_id(company_id: int) -> Optional[Dict]:
    # 실제 회사 정보 데이터베이스 조회 로직 구현
    # 현재는 간단한 예시로 더미 데이터 반환
    return {
        "companyId": company_id,
        "companyName": f"Company-{company_id}"
    }

