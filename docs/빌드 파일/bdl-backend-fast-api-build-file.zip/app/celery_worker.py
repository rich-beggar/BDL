"""
Celery 워커 설정 및 태스크 정의
"""
import os
import time
import platform
import requests
from celery import Celery
from celery.result import AsyncResult
import pytz
from dotenv import load_dotenv
# 장 운영 시간 확인
from app.services.algorithm_service import *
# DB 분봉,일봉 가지고 오기
from app.db.database import get_stock_minute_data, get_stock_daily_data

import logging
load_dotenv(verbose=True)
KST = pytz.timezone('Asia/Seoul')
logger = logging.getLogger("app.celery_worker")

# Windows 환경인지 확인
if platform.system().lower() == 'windows':
    # Windows에서는 eventlet 또는 gevent 풀 사용
    os.environ.setdefault('FORKED_BY_MULTIPROCESSING', '1')

# Celery 설정
redis_url = os.getenv("REDIS_URL")
celery_app = Celery('trading_tasks', broker=redis_url, backend=redis_url)
SPRING_SERVER_URL = os.getenv("SPRING_SERVER_URL")
SAND_RESULT_ENDPOINT = "/api/algorithm/auto-trading/signal"
# Windows에서는 풀 구현 변경
if platform.system().lower() == 'windows':
    # Windows에서는 solo 풀 사용 (gevent는 kill_job을 지원하지 않음)
    celery_app.conf.task_pool = 'solo'

celery_app.conf.update(
    # 직렬화 및 시간대 설정
    task_serializer='json',  # 작업 데이터를 JSON 형식으로 직렬화
    accept_content=['json'],  # JSON 형식의 컨텐츠만 수락
    result_serializer='json',  # 결과 데이터를 JSON 형식으로 직렬화
    timezone='Asia/Seoul',  # 한국 시간대 사용
    enable_utc=False,  # UTC 시간 대신 지정된 시간대 사용

    # 성능 및 안정성 설정
    worker_concurrency=12,  # 최대 12개의 작업을 처리
    task_acks_late=True,  # 작업 완료 후에만 메시지 확인(더 높은 안정성)
    task_reject_on_worker_lost=True,  # 작업자 연결이 끊기면 작업 거부(재시도 가능)
    task_track_started=True,  # 작업 시작 상태 추적 활성화
    broker_connection_retry_on_startup=True,  # 시작 시 브로커 연결 재시도

    # 시간 제한 및 취소 관련 설정
    task_time_limit=60,  # 작업 최대 실행 시간 1시간(초 단위)
    worker_state_db=None,  # 영구 작업 취소 상태 저장 비활성화(중요!)
    worker_cancel_long_running_tasks_on_connection_loss=True,
    # 연결 끊김 시 장시간 실행 작업 취소
    result_expires=60
)

#맨 처음 초기화 및 예약 코드
def schedule_next_run(algorithm_id, company_id, algorithm_data, check_type):
    """ 다음 실행 예약 함수 (ETA 방식 적용) """
    import time
    custom_task_id = f"{algorithm_id}_{company_id}_{int(time.time())}"
    now = datetime.now(KST)
    next_run_time = now
    #장이 열려 있지 않다면 다음날 9시
    if not is_market_open():
        logger.info(f"장이 닫혀 있습니다. {check_type} 체크를 다음 장 개장 시점으로 예약")

        # 다음 개장일 계산 (오늘 9시 이전이면 오늘, 이후면 다음 날)
        next_date = now.date() if now.hour < 9 else now.date() + timedelta(days=1)

        # 주말이면 월요일로 조정
        weekday = next_date.weekday()  # 0=월요일, 5=토요일, 6=일요일
        if weekday == 5:  # 토요일
            next_date += timedelta(days=2)
        elif weekday == 6:  # 일요일
            next_date += timedelta(days=1)

        # 다음 장 시작 시간 (9시 00분 01초)
        next_run_time = KST.localize(datetime(next_date.year, next_date.month, next_date.day, 9, 0, 1))

    else:
        if check_type == "minute":
            # 정확히 다음 분 1초에 실행
            next_run_time = KST.localize(datetime(now.year, now.month, now.day, now.hour, now.minute, 1) + timedelta(minutes=1))

        elif check_type == "daily":
            # 다음 날 9시 1분 실행
            next_run_time = KST.localize(datetime(now.year, now.month, now.day, 9, 1) + timedelta(days=1))

            # 주말 체크 (토요일이면 월요일로, 일요일이면 월요일로 조정)
            weekday = next_run_time.weekday()
            if weekday == 5:  # 토요일
                next_run_time += timedelta(days=2)
            elif weekday == 6:  # 일요일
                next_run_time += timedelta(days=1)

    # Celery 작업 예약 (ETA 적용)
    next_task = run_trading_algorithm.apply_async(
        args=[algorithm_id, company_id, algorithm_data, check_type],
        eta=next_run_time,  # 절대 시간 지정
        task_id = custom_task_id
    )
    # 상태 업데이트
    logger.info(f"다음 {check_type} 작업 예약 완료: {next_task.id}, 실행 예정 시각: {next_run_time}")

#실행 코드
@celery_app.task(bind=True)
def run_trading_algorithm(self, algorithm_id, company_id,
    algorithm_data, check_type, init=False):
    """
    단일 반복 실행 (분봉 또는 일봉 체크)
    - init=True: 초기 실행 시, 실행 없이 예약만 수행
    - init=False: 기존처럼 실행 후 다음 예약 수행
    """
    task_id = f"{algorithm_id}_{company_id}"
    celery_task_id = self.request.id

    # 최초 실행 시 정확한 시간 예약 후 종료
    if init:
        logger.info(f"초기 실행 - {check_type} 작업 예약 시작 (회사: {company_id})")
        schedule_next_run(algorithm_id, company_id, algorithm_data, check_type)
        return {"status": "initialized", "check_type": check_type}

    try:
        # 데이터 체크 및 신호 생성
        trading_result = None
        if check_type == "minute":
            trading_result = check_minute_data(algorithm_data, company_id)

        elif check_type == "daily":
            trading_result = check_daily_data(algorithm_data, company_id)

        # 매매 신호 처리
        send_trading_signal(algorithm_id, company_id, celery_task_id,
                                trading_result)

        schedule_next_run(algorithm_id, company_id, algorithm_data, check_type)

        return {"status": "success", "check_type": check_type,
                "signal": trading_result.get(
                    "signal") if trading_result else None}

    except Exception as e:
        logger.exception(f"알고리즘 실행 중 오류 발생: {str(e)}")

        # 오류가 발생해도 다음 작업 예약
        schedule_next_run(algorithm_id, company_id, algorithm_data,
                          check_type)
        return {"status": "error", "error": str(e),
                    "check_type": check_type}
    finally:
        # 자기 메타데이터 삭제
        try:
            # AsyncResult.forget() 대신 직접 Redis에서 삭제
            task_id = self.request.id
            redis_client = self.app.backend.client  # Redis 클라이언트 가져오기
            key = f"celery-task-meta-{task_id}"
            redis_client.delete(key)
        except Exception as e:
            logger.warning(f"메타데이터 삭제 중 오류: {str(e)}")


def send_trading_signal(algorithm_id, company_id, celery_task_id,
    trading_result, last_signal=None):
    """신호 전송 함수"""
    signal = trading_result["signal"]
    reasons = trading_result.get("reasons", [])

    # 같은 신호 중복 전송 방지
    if signal == last_signal:
        logger.info(f"중복 신호 전송 방지: {signal}")
        return

    # Spring 서버에 신호 전송
    try:
        # NumPy 타입을 Python 기본 타입으로 변환
        payload = {
            "message": signal,
            "algorithmId": algorithm_id,
            "companyId": company_id,
            "celeryTaskId": celery_task_id,
            "status": "RUNNING",
            "reasons": reasons
        }

        # lastPrice와 priceChangePercent가 있으면 기본 타입으로 변환
        if "lastPrice" in trading_result and trading_result["lastPrice"] is not None:
            payload["lastPrice"] = float(trading_result["lastPrice"])

        if "priceChangePercent" in trading_result and trading_result[
            "priceChangePercent"] is not None:
            payload["priceChangePercent"] = float(
                trading_result["priceChangePercent"])

        signal_url = f"{SPRING_SERVER_URL}{SAND_RESULT_ENDPOINT}"
        response = requests.post(
            signal_url,
            json=payload,
            timeout=5
        )

        if response.status_code == 200:
            logger.info(
                f"매매 신호 전송 성공: 알고리즘 {algorithm_id}, 회사 {company_id}, 신호: {signal}")
        else:
            logger.warning(f"매매 신호 전송 실패: 상태 코드 {response.status_code}")
    except Exception as e:
        logger.error(f"매매 신호 전송 중 오류 발생: {str(e)}")
