"""
FastAPI 앱 초기화 및 설정
"""
from fastapi import FastAPI
from app.api.endpoints import trading
from app.core.events import lifespan
import logging

# 로거 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("app")

# FastAPI 앱 초기화
app = FastAPI(
    title="Algorithm Trading API",
    lifespan=lifespan,
    description="자동 트레이딩 알고리즘 API"
)

# 라우터 등록
app.include_router(trading.router, prefix="/fastapi")

# 서버가 실행 중인지 테스트하기 위한 간단한 루트 경로
@app.get("/")
async def root():
    return {"message": "알고리즘 트레이딩 API 서버가 실행 중입니다."}