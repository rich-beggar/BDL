# inspection.py 같은 파일 생성
from app.core.tasks import get_celery_app  # 여기에 celery_app을 import 하는 방법을 적용

celery_app = get_celery_app()

i = celery_app.control.inspect()
scheduled = i.scheduled()
print("Scheduled tasks:", scheduled)

scheduled = i.active()
print("active tasks:", scheduled)

reserved = i.reserved()
print("Reserved tasks:", reserved)

revoked = i.revoked()
print("Revoked tasks:", revoked)