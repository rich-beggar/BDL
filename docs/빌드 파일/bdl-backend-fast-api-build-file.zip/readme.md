### 파이썬 자동매매 API 코드


- Spring에서 RestAPI로 자동매매 백그라운드로 실행
- 신호 잡히면 Spring으로 response

- 배포 test2